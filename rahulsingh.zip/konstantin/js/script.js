function toggleMobileMenu(menu) {
  debugger;
  menu.classList.toggle('open');
}